document.getElementById('registerBtn').addEventListener('click', function() {
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const mobile = document.getElementById('mobile').value;
    const password = document.getElementById('password').value;
    const otp = document.getElementById('otp').value;

    // Simple validation
    if (name && (email || mobile) && password && otp) {
        alert('Registration successful!');
        // Here you would send the data to your server via AJAX or Fetch API
    } else {
        alert('Please fill in all the fields and provide an OTP');
    }
});

