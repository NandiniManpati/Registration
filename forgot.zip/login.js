document.getElementById('loginBtn').addEventListener('click', function() {
    const email_mobile = document.getElementById('email_mobile').value;
    const password = document.getElementById('password').value;
    const otp = document.getElementById('otp').value;

    // Simple validation
    if (email_mobile && (password || otp)) {
        alert('Login successful!');
        // Here you would send the data to your server via AJAX or Fetch API
    } else {
        alert('Please provide your email/mobile and password or OTP.');
    }
});
