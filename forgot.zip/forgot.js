document.getElementById('resetPasswordBtn').addEventListener('click', function() {
    const email_mobile = document.getElementById('email_mobile').value;

    if (email_mobile) {
        alert('A password reset link has been sent to your email/mobile!');
        // Here you would send the reset link via AJAX or Fetch API
    } else {
        alert('Please provide your email or mobile.');
    }
});
